package ui;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import data.Database;
import model.Penginapan;
import java.awt.*;
import java.awt.event.*;

public class FormPenginapan extends JPanel {
    private final JTextField tfId = new JTextField();
    private final JTextField tfName = new JTextField();
    private final JTextField tfFoto = new JTextField();
    private final JTextField tfDeskripsi = new JTextField();
    private final JTextField tfLat = new JTextField();
    private final JTextField tfLng = new JTextField();

    private final JButton btnTambah = new JButton("Tambah");
    private final JButton btnEdit = new JButton("Edit");
    private final JButton btnHapus = new JButton("Hapus");

    private final JTable table;
    private final DefaultTableModel tableModel;

    public FormPenginapan() {
        setLayout(new BorderLayout(20, 20));
        setBackground(new Color(245, 248, 250));
        setBorder(new EmptyBorder(20, 30, 20, 30));

        JLabel title = new JLabel("Manajemen Penginapan");
        title.setFont(new Font("Segoe UI Semibold", Font.BOLD, 24));
        title.setForeground(new Color(33, 37, 41));
        add(title, BorderLayout.NORTH);

        JPanel mainPanel = new JPanel(new GridLayout(1, 2, 20, 0));
        mainPanel.setOpaque(false);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        formPanel.setBorder(new CompoundBorder(
            new TitledBorder("🏨 Form Penginapan"),
            new EmptyBorder(20, 20, 20, 20)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;

        addFormField(formPanel, gbc, "ID Penginapan", tfId);
        addFormField(formPanel, gbc, "Nama Penginapan", tfName);
        addFormField(formPanel, gbc, "Foto", tfFoto);
        addFormField(formPanel, gbc, "Deskripsi", tfDeskripsi);
        addFormField(formPanel, gbc, "Latitude", tfLat);
        addFormField(formPanel, gbc, "Longitude", tfLng);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 10));
        btnPanel.setOpaque(false);
        JButton[] buttons = {btnTambah, btnEdit, btnHapus};

        for (JButton btn : buttons) {
            btn.setPreferredSize(new Dimension(110, 36));
            btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
            btn.setBackground(new Color(0, 123, 255));
            btn.setForeground(Color.WHITE);
            btn.setFocusPainted(false);
            btn.setBorder(BorderFactory.createLineBorder(new Color(0, 123, 255)));
            btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

            btn.addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) {
                    btn.setBackground(new Color(0, 105, 230));
                }
                public void mouseExited(MouseEvent e) {
                    btn.setBackground(new Color(0, 123, 255));
                }
            });

            btnPanel.add(btn);
        }

        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        formPanel.add(btnPanel, gbc);

        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(Color.WHITE);
        tablePanel.setBorder(new CompoundBorder(
            new TitledBorder("📋 Daftar Penginapan"),
            new EmptyBorder(10, 10, 10, 10)
        ));

        String[] columnNames = {"ID", "Nama", "Foto", "Deskripsi", "Latitude", "Longitude"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            public boolean isCellEditable(int row, int col) {
                return false;
            }
        };

        table = new JTable(tableModel);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(28);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(new Color(230, 240, 255));
        table.setSelectionBackground(new Color(200, 230, 250));
        table.setGridColor(new Color(220, 220, 220));
        table.setShowVerticalLines(false);

        JScrollPane scroll = new JScrollPane(table);
        tablePanel.add(scroll, BorderLayout.CENTER);

        mainPanel.add(formPanel);
        mainPanel.add(tablePanel);
        add(mainPanel, BorderLayout.CENTER);

        btnTambah.addActionListener(e -> tambah());
        btnEdit.addActionListener(e -> edit());
        btnHapus.addActionListener(e -> hapus());

        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int i = table.getSelectedRow();
                if (i != -1) {
                    tfId.setText(table.getValueAt(i, 0).toString());
                    tfName.setText(table.getValueAt(i, 1).toString());
                    tfFoto.setText(table.getValueAt(i, 2).toString());
                    tfDeskripsi.setText(table.getValueAt(i, 3).toString());
                    tfLat.setText(table.getValueAt(i, 4).toString());
                    tfLng.setText(table.getValueAt(i, 5).toString());
                }
            }
        });

        refreshTable();
    }

    private void addFormField(JPanel panel, GridBagConstraints gbc, String label, JTextField field) {
        JLabel lbl = new JLabel(label);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 14));
        gbc.gridx = 0;
        panel.add(lbl, gbc);

        field.setPreferredSize(new Dimension(200, 30));
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            new EmptyBorder(5, 10, 5, 10)
        ));

        gbc.gridx = 1;
        panel.add(field, gbc);
        gbc.gridy++;
    }

    private void tambah() {
        Penginapan p = new Penginapan(
            tfId.getText(),
            tfName.getText(),
            tfFoto.getText(),
            tfDeskripsi.getText(),
            tfLat.getText(),
            tfLng.getText()
        );
        Database.penginapanList.add(p);
        refreshTable();
        clear();
    }

    private void edit() {
        int i = table.getSelectedRow();
        if (i != -1) {
            Penginapan p = Database.penginapanList.get(i);
            p.setIdPenginapan(tfId.getText());
            p.setNamaPenginapan(tfName.getText());
            p.setFotoPenginapan(tfFoto.getText());
            p.setDeskripsiPenginapan(tfDeskripsi.getText());
            p.setLatPenginapan(tfLat.getText());
            p.setLongPenginapan(tfLng.getText());
            refreshTable();
            clear();
        } else {
            JOptionPane.showMessageDialog(this, "Pilih data yang ingin diedit!", "Peringatan", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void hapus() {
        int i = table.getSelectedRow();
        if (i != -1) {
            int confirm = JOptionPane.showConfirmDialog(this, "Yakin ingin menghapus data ini?", "Konfirmasi", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                Database.penginapanList.remove(i);
                refreshTable();
                clear();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Pilih data yang ingin dihapus!", "Peringatan", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        for (Penginapan p : Database.penginapanList) {
            tableModel.addRow(new Object[]{
                p.getIdPenginapan(),
                p.getNamaPenginapan(),
                p.getFotoPenginapan(),
                p.getDeskripsiPenginapan(),
                p.getLatPenginapan(),
                p.getLongPenginapan()
            });
        }
    }

    private void clear() {
        tfId.setText("");
        tfName.setText("");
        tfFoto.setText("");
        tfDeskripsi.setText("");
        tfLat.setText("");
        tfLng.setText("");
        table.clearSelection();
    }
}
