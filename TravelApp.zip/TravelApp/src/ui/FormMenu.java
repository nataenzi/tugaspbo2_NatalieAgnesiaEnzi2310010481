package ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;

public class FormMenu extends JFrame {
    private boolean isMaximized = false;
    private Rectangle windowRestoreBounds;

    public FormMenu() {
        setTitle("TravelApp - Sistem Informasi Pariwisata");
        setSize(1100, 720);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setUndecorated(true);
        setBackground(new Color(0, 0, 0, 0));
        setResizable(true);

        // SHADOW PANEL
        JPanel shadowPanel = new JPanel(new BorderLayout());
        shadowPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        shadowPanel.setOpaque(false);

        // CONTAINER PANEL UTAMA
        JPanel mainPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Color.WHITE);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 25, 25);
            }
        };
        mainPanel.setOpaque(false);

        // ========== HEADER ========== //
        JPanel header = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(0, 0, new Color(0, 130, 200),
                        getWidth(), getHeight(), new Color(0, 180, 240));
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 25, 25);
            }
        };
        header.setPreferredSize(new Dimension(getWidth(), 70));
        header.setLayout(new BorderLayout(10, 0));
        header.setBorder(BorderFactory.createEmptyBorder(0, 25, 0, 20));

        JLabel title = new JLabel("TravelApp");
        title.setFont(new Font("Segoe UI Semibold", Font.BOLD, 26));
        title.setForeground(Color.WHITE);

        // Tombol kontrol kanan atas
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 20));
        controlPanel.setOpaque(false);

        JButton btnMin = createHeaderButton("–");
        JButton btnMax = createHeaderButton("⬜");
        JButton btnClose = createHeaderButton("X");

        btnMin.addActionListener(e -> setState(Frame.ICONIFIED));
        btnMax.addActionListener(e -> toggleMaximize());
        btnClose.addActionListener(e -> System.exit(0));

        controlPanel.add(btnMin);
        controlPanel.add(btnMax);
        controlPanel.add(btnClose);

        header.add(title, BorderLayout.WEST);
        header.add(controlPanel, BorderLayout.EAST);

        // ========== TABBED PANE ========== //
        JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
        tabbedPane.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        tabbedPane.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        tabbedPane.setBackground(Color.WHITE);
        tabbedPane.setFocusable(false);

        tabbedPane.addTab("User", new FormUser());
        tabbedPane.addTab("Wisata", new FormWisata());
        tabbedPane.addTab("Kategori", new FormKategori());
        tabbedPane.addTab("Penginapan", new FormPenginapan());

        // ========== GABUNGKAN PANEL ==========
        mainPanel.add(header, BorderLayout.NORTH);
        mainPanel.add(tabbedPane, BorderLayout.CENTER);
        shadowPanel.add(mainPanel, BorderLayout.CENTER);
        add(shadowPanel, BorderLayout.CENTER);

        // Sudut membulat adaptif
        addComponentListener(new ComponentAdapter() {
            public void componentResized(ComponentEvent e) {
                if (!isMaximized) {
                    setShape(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 25, 25));
                } else {
                    setShape(null);
                }
            }
        });

        setVisible(true);
    }

    private JButton createHeaderButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btn.setForeground(Color.WHITE);
        btn.setContentAreaFilled(false);
        btn.setBorder(null);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btn.setForeground(new Color(220, 220, 220));
            }

            public void mouseExited(MouseEvent e) {
                btn.setForeground(Color.WHITE);
            }
        });

        return btn;
    }

    private void toggleMaximize() {
        if (isMaximized) {
            setBounds(windowRestoreBounds);
            setShape(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 25, 25));
        } else {
            windowRestoreBounds = getBounds();
            GraphicsEnvironment env = GraphicsEnvironment.getLocalGraphicsEnvironment();
            Rectangle bounds = env.getMaximumWindowBounds();
            setBounds(bounds);
            setShape(null);
        }
        isMaximized = !isMaximized;
    }
}
