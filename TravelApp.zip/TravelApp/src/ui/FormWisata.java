package ui;

import model.Wisata;
import data.Database;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;

public class FormWisata extends JPanel {
    private final JTextField tfId = new JTextField(20);
    private final JTextField tfKategori = new JTextField(20);
    private final JTextField tfNama = new JTextField(20);
    private final JTextField tfFoto = new JTextField(20);
    private final JTextField tfDeskripsi = new JTextField(20);
    private final JTextField tfLat = new JTextField(20);
    private final JTextField tfLong = new JTextField(20);

    private final JButton btnTambah = new JButton("Tambah");
    private final JButton btnEdit = new JButton("️Edit");
    private final JButton btnHapus = new JButton("Hapus");

    private final JTable table;
    private final DefaultTableModel tableModel;

    public FormWisata() {
        setLayout(new BorderLayout(20, 20));
        setBackground(new Color(245, 248, 250));
        setBorder(new EmptyBorder(20, 30, 20, 30));

        JLabel title = new JLabel("Manajemen Wisata");
        title.setFont(new Font("Segoe UI Semibold", Font.BOLD, 24));
        title.setForeground(new Color(33, 37, 41));
        add(title, BorderLayout.NORTH);

        // === PANEL UTAMA ===
        JPanel mainPanel = new JPanel(new GridLayout(1, 2, 20, 0));
        mainPanel.setOpaque(false);

        // === PANEL FORM KIRI ===
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        formPanel.setBorder(new CompoundBorder(
            new TitledBorder("📝 Form Wisata"),
            new EmptyBorder(20, 20, 20, 20)
        ));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;

        String[] labels = {
            "ID Wisata", "ID Kategori", "Nama Wisata", "Foto", "Deskripsi", "Latitude", "Longitude"
        };
        JTextField[] fields = {
            tfId, tfKategori, tfNama, tfFoto, tfDeskripsi, tfLat, tfLong
        };

        for (int i = 0; i < labels.length; i++) {
            JLabel lbl = new JLabel(labels[i]);
            lbl.setFont(new Font("Segoe UI", Font.BOLD, 14));
            gbc.gridx = 0;
            formPanel.add(lbl, gbc);

            fields[i].setFont(new Font("Segoe UI", Font.PLAIN, 14));
            fields[i].setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                new EmptyBorder(6, 10, 6, 10)
            ));
            gbc.gridx = 1;
            formPanel.add(fields[i], gbc);

            gbc.gridy++;
        }

        // === BUTTON PANEL ===
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 10));
        btnPanel.setOpaque(false);

        JButton[] buttons = {btnTambah, btnEdit, btnHapus};
        for (JButton btn : buttons) {
            btn.setPreferredSize(new Dimension(110, 38));
            btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
            btn.setBackground(new Color(0, 123, 255));
            btn.setForeground(Color.WHITE);
            btn.setFocusPainted(false);
            btn.setBorder(BorderFactory.createLineBorder(new Color(0, 123, 255)));
            btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            btn.addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) {
                    btn.setBackground(new Color(0, 105, 230));
                }

                public void mouseExited(MouseEvent e) {
                    btn.setBackground(new Color(0, 123, 255));
                }
            });
            btnPanel.add(btn);
        }

        gbc.gridwidth = 2;
        formPanel.add(btnPanel, gbc);

        // === TABLE PANEL KANAN ===
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(Color.WHITE);
        tablePanel.setBorder(new CompoundBorder(
            new TitledBorder("📋 Daftar Wisata"),
            new EmptyBorder(10, 10, 10, 10)
        ));

        String[] columnNames = {
            "ID", "Kategori", "Nama", "Foto", "Deskripsi", "Lat", "Long"
        };
        tableModel = new DefaultTableModel(columnNames, 0) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(tableModel);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(28);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(new Color(230, 240, 255));
        table.setSelectionBackground(new Color(200, 230, 250));

        JScrollPane scroll = new JScrollPane(table);
        tablePanel.add(scroll, BorderLayout.CENTER);

        mainPanel.add(formPanel);
        mainPanel.add(tablePanel);
        add(mainPanel, BorderLayout.CENTER);

        // === EVENTS ===
        refreshTable();

        btnTambah.addActionListener(e -> tambah());
        btnEdit.addActionListener(e -> edit());
        btnHapus.addActionListener(e -> hapus());

        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int i = table.getSelectedRow();
                if (i != -1) {
                    tfId.setText(tableModel.getValueAt(i, 0).toString());
                    tfKategori.setText(tableModel.getValueAt(i, 1).toString());
                    tfNama.setText(tableModel.getValueAt(i, 2).toString());
                    tfFoto.setText(tableModel.getValueAt(i, 3).toString());
                    tfDeskripsi.setText(tableModel.getValueAt(i, 4).toString());
                    tfLat.setText(tableModel.getValueAt(i, 5).toString());
                    tfLong.setText(tableModel.getValueAt(i, 6).toString());
                }
            }
        });
    }

    private void tambah() {
        try {
            Wisata w = new Wisata(
                Integer.parseInt(tfId.getText().trim()),
                Integer.parseInt(tfKategori.getText().trim()),
                tfNama.getText().trim(),
                tfFoto.getText().trim(),
                tfDeskripsi.getText().trim(),
                tfLat.getText().trim(),
                tfLong.getText().trim()
            );
            Database.wisataList.add(w);
            refreshTable();
            clear();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Pastikan semua data valid!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void edit() {
        int i = table.getSelectedRow();
        if (i != -1) {
            try {
                Wisata w = Database.wisataList.get(i);
                w.setIdWisata(Integer.parseInt(tfId.getText().trim()));
                w.setIdKategori(Integer.parseInt(tfKategori.getText().trim()));
                w.setNamaWisata(tfNama.getText().trim());
                w.setFotoWisata(tfFoto.getText().trim());
                w.setDeskripsiWisata(tfDeskripsi.getText().trim());
                w.setLatWisata(tfLat.getText().trim());
                w.setLongWisata(tfLong.getText().trim());
                refreshTable();
                clear();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Data tidak valid!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void hapus() {
        int i = table.getSelectedRow();
        if (i != -1) {
            int confirm = JOptionPane.showConfirmDialog(this, "Yakin ingin menghapus data ini?", "Konfirmasi", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                Database.wisataList.remove(i);
                refreshTable();
                clear();
            }
        }
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        for (Wisata w : Database.wisataList) {
            tableModel.addRow(new Object[]{
                w.getIdWisata(),
                w.getIdKategori(),
                w.getNamaWisata(),
                w.getFotoWisata(),
                w.getDeskripsiWisata(),
                w.getLatWisata(),
                w.getLongWisata()
            });
        }
    }

    private void clear() {
        tfId.setText("");
        tfKategori.setText("");
        tfNama.setText("");
        tfFoto.setText("");
        tfDeskripsi.setText("");
        tfLat.setText("");
        tfLong.setText("");
        table.clearSelection();
    }
}
