package model;

public class Penginapan {
    private String idPenginapan;
    private String namaPenginapan;
    private String fotoPenginapan;
    private String deskripsiPenginapan;
    private String latPenginapan;
    private String longPenginapan;

    // Constructor
    public Penginapan(String idPenginapan, String namaPenginapan, String fotoPenginapan,
                      String deskripsiPenginapan, String latPenginapan, String longPenginapan) {
        this.idPenginapan = idPenginapan;
        this.namaPenginapan = namaPenginapan;
        this.fotoPenginapan = fotoPenginapan;
        this.deskripsiPenginapan = deskripsiPenginapan;
        this.latPenginapan = latPenginapan;
        this.longPenginapan = longPenginapan;
    }

    // Getters and Setters
    public String getIdPenginapan() {
        return idPenginapan;
    }

    public void setIdPenginapan(String idPenginapan) {
        this.idPenginapan = idPenginapan;
    }

    public String getNamaPenginapan() {
        return namaPenginapan;
    }

    public void setNamaPenginapan(String namaPenginapan) {
        this.namaPenginapan = namaPenginapan;
    }

    public String getFotoPenginapan() {
        return fotoPenginapan;
    }

    public void setFotoPenginapan(String fotoPenginapan) {
        this.fotoPenginapan = fotoPenginapan;
    }

    public String getDeskripsiPenginapan() {
        return deskripsiPenginapan;
    }

    public void setDeskripsiPenginapan(String deskripsiPenginapan) {
        this.deskripsiPenginapan = deskripsiPenginapan;
    }

    public String getLatPenginapan() {
        return latPenginapan;
    }

    public void setLatPenginapan(String latPenginapan) {
        this.latPenginapan = latPenginapan;
    }

    public String getLongPenginapan() {
        return longPenginapan;
    }

    public void setLongPenginapan(String longPenginapan) {
        this.longPenginapan = longPenginapan;
    }

    // toString
    @Override
    public String toString() {
        return "ID: " + idPenginapan +
               ", Nama: " + namaPenginapan +
               ", Foto: " + fotoPenginapan +
               ", Deskripsi: " + deskripsiPenginapan +
               ", Lat: " + latPenginapan +
               ", Long: " + longPenginapan;
    }
}
