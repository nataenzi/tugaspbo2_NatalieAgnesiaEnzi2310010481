package model;

public class Wisata {
    private int idWisata;
    private int idKategori;
    private String namaWisata;
    private String fotoWisata;
    private String deskripsiWisata;
    private String latWisata;
    private String longWisata;

    // Constructor
    public Wisata(int idWisata, int idKategori, String namaWisata, String fotoWisata, 
                  String deskripsiWisata, String latWisata, String longWisata) {
        this.idWisata = idWisata;
        this.idKategori = idKategori;
        this.namaWisata = namaWisata;
        this.fotoWisata = fotoWisata;
        this.deskripsiWisata = deskripsiWisata;
        this.latWisata = latWisata;
        this.longWisata = longWisata;
    }

    // Getter dan Setter
    public int getIdWisata() {
        return idWisata;
    }

    public void setIdWisata(int idWisata) {
        this.idWisata = idWisata;
    }

    public int getIdKategori() {
        return idKategori;
    }

    public void setIdKategori(int idKategori) {
        this.idKategori = idKategori;
    }

    public String getNamaWisata() {
        return namaWisata;
    }

    public void setNamaWisata(String namaWisata) {
        this.namaWisata = namaWisata;
    }

    public String getFotoWisata() {
        return fotoWisata;
    }

    public void setFotoWisata(String fotoWisata) {
        this.fotoWisata = fotoWisata;
    }

    public String getDeskripsiWisata() {
        return deskripsiWisata;
    }

    public void setDeskripsiWisata(String deskripsiWisata) {
        this.deskripsiWisata = deskripsiWisata;
    }

    public String getLatWisata() {
        return latWisata;
    }

    public void setLatWisata(String latWisata) {
        this.latWisata = latWisata;
    }

    public String getLongWisata() {
        return longWisata;
    }

    public void setLongWisata(String longWisata) {
        this.longWisata = longWisata;
    }

    @Override
    public String toString() {
        return "ID: " + idWisata +
               ", Kategori: " + idKategori +
               ", Nama: " + namaWisata +
               ", Foto: " + fotoWisata +
               ", Deskripsi: " + deskripsiWisata +
               ", Latitude: " + latWisata +
               ", Longitude: " + longWisata;
    }
}
